package com.example.demo.tables;

public class Task {
}
