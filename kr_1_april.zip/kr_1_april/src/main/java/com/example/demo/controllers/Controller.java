package com.example.demo.controllers;

import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.TaskRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/Kr29")
public class Controller {
    private final UserRepository userRepository;
    private final TaskRepository taskRepository;
    private final CategoryRepository categoryRepository;

    public ClientController(UserRepository userRepository) {
        this.userRepository=userRepository;
    }

    @PostMapping("/adduser")
    User createUser(@RequestBody User user) {
        System.out.println(user);
        return this.userRepository.save(user);
    }
    @PostMapping("/addtask")
    Task createTask(@RequestBody Task task) {
    }
    @PostMapping("/categories")
    Category createCategory(@RequestBody Category createCategory){
        System.out.println(createCategory);
        return categoryRepository.save(createCategory);
    }
}